/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  * @developer      : Amiya Krishna Gupta
  * @start_date     : 11 August 2025
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd_hmi.h"
#include "button_matrix.h"
#include "action_comm.h"
#include "sensor_manager.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE BEGIN PV */

volatile uint8_t key_matrix[7][5];
// [column][row] → 1 = pressed, 0 = not pressed
/* USER CODE BEGIN PD */

#define COL_HIGH(port, pin) HAL_GPIO_WritePin(port, pin, GPIO_PIN_SET)
#define COL_LOW(port, pin)  HAL_GPIO_WritePin(port, pin, GPIO_PIN_RESET)

/* USER CODE END PD */

/* USER CODE END PV */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
void LCD_TestAllPages(void)
{
    uint8_t packet[10] = {0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x00 };
    for(uint8_t page = 0x01; page <= 0x32; page++)
    {
        packet[9] = page;

        HAL_UART_Transmit(&huart2, packet, 10, HAL_MAX_DELAY);
        HAL_Delay(2000);
    }
}

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_CAN_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();

  LCD_HMI_Init(&huart2);
  ACTION_COMM_Init(&huart3, &huart1);
  Sensor_Init();
  HAL_GPIO_WritePin(C1_GPIO_Port, GPIO_PIN_4, RESET);
  HAL_GPIO_WritePin(C2_GPIO_Port, GPIO_PIN_5, RESET);
  HAL_GPIO_WritePin(C3_GPIO_Port, GPIO_PIN_6, RESET);
  HAL_GPIO_WritePin(C4_GPIO_Port, GPIO_PIN_7, RESET);
  HAL_GPIO_WritePin(C5_GPIO_Port, GPIO_PIN_0, RESET);
  HAL_GPIO_WritePin(C6_GPIO_Port, GPIO_PIN_1, RESET);
  HAL_GPIO_WritePin(C7_GPIO_Port, GPIO_PIN_2, RESET);
  LCD_ShowStartupSequence();
  while (1)
  {
      BUTTON_MATRIX_Scan();
      Sensor_UpdateDisplay();
      LCD_Task();
  }

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 16;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_1TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, C1_Pin|C2_Pin|C3_Pin|C4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, C5_Pin|C6_Pin|C7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : C1_Pin C2_Pin C3_Pin C4_Pin */
  GPIO_InitStruct.Pin = C1_Pin|C2_Pin|C3_Pin|C4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : C5_Pin C6_Pin C7_Pin */
  GPIO_InitStruct.Pin = C5_Pin|C6_Pin|C7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : R1_Pin R2_Pin R3_Pin R4_Pin */
  GPIO_InitStruct.Pin = R1_Pin|R2_Pin|R3_Pin|R4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : R5_Pin */
  GPIO_InitStruct.Pin = R5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(R5_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
//
//uint8_t hmiPacket[8];
//char tx[64];
//
//uint8_t basePacket[16] =
//{
//    0x43, 0x47, 0xFE,
//    0x00,
//    0x00, 0x00, 0x00, 0x01, 0x00,
//    0x95, 0xA5, 0xB5, 0xC5, 0xD5,
//    0x00, 0x4E
//};
//
//const uint8_t keyCmdCode[7][5] =
//{
//    {0x15,0x16,0x17,0x18,0x00},
//    {0x23,0x22,0x21,0x20,0x00},
//    {0x14,0x02,0x01,0x13,0x00},
//    {0x12,0x04,0x03,0x11,0x00},
//    {0x24,0x06,0x05,0x25,0x00},
//    {0x19,0x08,0x07,0x26,0x00},
//    {0x28,0x10,0x09,0x27,0x00}
//};
//
//uint8_t packet[16];
//uint32_t keyPressTick[7][5] = {0};
//uint8_t  longSent[7][5] = {0};
//
//void Send_Action_Packet(uint8_t cmd)
//{
//    memcpy(packet, basePacket, 16);
//    packet[3] = cmd;
//    HAL_UART_Transmit(&huart1, packet, 16, HAL_MAX_DELAY);
//    HAL_UART_Transmit(&huart3, packet, 16, HAL_MAX_DELAY);
//}
//
////void Send_HMI_Packet(uint8_t cmd, uint8_t isLong)
////{
////    hmiPacket[0]=0x5A; hmiPacket[1]=0xA5; hmiPacket[2]=0x05;
////    hmiPacket[3]=0x82; hmiPacket[4]=0x00; hmiPacket[5]=cmd;
////    hmiPacket[6]=0x00;
////    hmiPacket[7]= isLong ? 0x01 : 0x00;
////    HAL_UART_Transmit(&huart2, hmiPacket, 8, HAL_MAX_DELAY);
////}
//
//void Scan_Button_Matrix(void)
//{
//    GPIO_TypeDef* col_port[7]={C1_GPIO_Port,C2_GPIO_Port,C3_GPIO_Port,C4_GPIO_Port,C5_GPIO_Port,C6_GPIO_Port,C7_GPIO_Port};
//    uint16_t col_pin[7]={C1_Pin,C2_Pin,C3_Pin,C4_Pin,C5_Pin,C6_Pin,C7_Pin};
//
//    GPIO_TypeDef* row_port[5]={R1_GPIO_Port,R2_GPIO_Port,R3_GPIO_Port,R4_GPIO_Port,R5_GPIO_Port};
//    uint16_t row_pin[5]={R1_Pin,R2_Pin,R3_Pin,R4_Pin,R5_Pin};
//
//    static uint8_t stableCount[7][5]={0};
//
//    for(int c=0;c<7;c++)
//    {
//        for(int i=0;i<7;i++) HAL_GPIO_WritePin(col_port[i],col_pin[i],GPIO_PIN_RESET);
//        HAL_GPIO_WritePin(col_port[c],col_pin[c],GPIO_PIN_SET);
//        HAL_Delay(2);
//
//        for(int r=0;r<5;r++)
//        {
//            uint8_t raw = (HAL_GPIO_ReadPin(row_port[r],row_pin[r])==GPIO_PIN_SET);
//
//            if(raw){ if(stableCount[c][r]<5) stableCount[c][r]++; }
//            else   { if(stableCount[c][r]>0) stableCount[c][r]--; }
//
//            if(stableCount[c][r]==4 && key_matrix[c][r]==0)
//            {
//                key_matrix[c][r]=1;
//                keyPressTick[c][r]=HAL_GetTick();
//                longSent[c][r]=0;
//            }
//
//            if(key_matrix[c][r] && !longSent[c][r] && (HAL_GetTick()-keyPressTick[c][r]>=600))
//            {
//                longSent[c][r]=1;
//                uint8_t cmd=keyCmdCode[c][r];
//                if(cmd){ Send_Action_Packet(cmd); LCD_SendKeyEvent(cmd, LCD_KEY_LONG); }
//            }
//
//            if(stableCount[c][r]==0 && key_matrix[c][r])
//            {
//                key_matrix[c][r]=0;
//                uint8_t cmd=keyCmdCode[c][r];
//                if(cmd && !longSent[c][r]){ Send_Action_Packet(cmd); LCD_SendKeyEvent(cmd, LCD_KEY_SHORT);
// }
//            }
//        }
//    }
//}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
