#include "button_matrix.h"
#include "lcd_hmi.h"
#include "action_comm.h"
#include "main.h"
#include "sensor_manager.h"

#define LONG_PRESS_TIME     600
#define DEBOUNCE_MAX        5
#define DEBOUNCE_TRIGGER    4
static uint8_t key_matrix[7][5] = {0};
static uint8_t stableCount[7][5] = {0};
static uint8_t comboLatch_Tilt   = 0;
static uint8_t comboLatch_Slide  = 0;
static uint8_t comboLatch_Height = 0;
static const uint8_t keyCmdCode[7][5] =
{
    {0x00,0x00,0x00,0x00,0x00},
    {0x00,0x00,0x00,0x00,0x00},
    {0x14,0x02,0x01,0x13,0x00},
    {0x12,0x04,0x03,0x11,0x00},
    {0x00,0x06,0x05,0x00,0x00},
    {0x19,0x08,0x07,0x00,0x00},
    {0x00,0x10,0x09,0x00,0x00}
};

void BUTTON_MATRIX_Scan(void)
{
    GPIO_TypeDef* col_port[7] =
    {
        C1_GPIO_Port,C2_GPIO_Port,C3_GPIO_Port,
        C4_GPIO_Port,C5_GPIO_Port,C6_GPIO_Port,C7_GPIO_Port
    };

    uint16_t col_pin[7] =
    {
        C1_Pin,C2_Pin,C3_Pin,C4_Pin,
        C5_Pin,C6_Pin,C7_Pin
    };

    GPIO_TypeDef* row_port[5] =
    {
        R1_GPIO_Port,R2_GPIO_Port,
        R3_GPIO_Port,R4_GPIO_Port,R5_GPIO_Port
    };

    uint16_t row_pin[5] =
    {
        R1_Pin,R2_Pin,R3_Pin,R4_Pin,R5_Pin
    };

    /* ================= MATRIX SCAN ================= */

    for(int c = 0; c < 7; c++)
    {
        for(int i = 0; i < 7; i++)
            HAL_GPIO_WritePin(col_port[i], col_pin[i], GPIO_PIN_RESET);

        HAL_GPIO_WritePin(col_port[c], col_pin[c], GPIO_PIN_SET);
        HAL_Delay(1);

        for(int r = 0; r < 5; r++)
        {
            uint8_t raw =
                (HAL_GPIO_ReadPin(row_port[r], row_pin[r]) == GPIO_PIN_SET);

            if(raw)
            {
                if(stableCount[c][r] < DEBOUNCE_MAX)
                    stableCount[c][r]++;
            }
            else
            {
                if(stableCount[c][r] > 0)
                    stableCount[c][r]--;
            }
        }
    }

    /* ================= DOUBLE BUTTON COMBOS ================= */

    if(!LCD_IsLocked() && LCD_IsPowerOn())
    {
        uint8_t goBack   = (stableCount[1][3] >= DEBOUNCE_TRIGGER);
        uint8_t accept   = (stableCount[1][0] >= DEBOUNCE_TRIGGER);
        uint8_t heightDn = (stableCount[2][1] >= DEBOUNCE_TRIGGER);
        uint8_t flexUp   = (stableCount[3][3] >= DEBOUNCE_TRIGGER);
        uint8_t slide    = (stableCount[6][2] >= DEBOUNCE_TRIGGER);

        /* ---- GoBack + Accept ---- */
        if(goBack && accept)
        {
            if(!comboLatch_Height)
            {
                comboLatch_Height = 1;
                comboLatch_Tilt   = 0;
                comboLatch_Slide  = 0;

                ACTION_SendCommand(0x00);
                LCD_StopCircularAnim();
                LCD_ShowSensorPage(GOBACK_ACCEPT);
            }
            return;
        }
        else comboLatch_Height = 0;

        /* ---- GoBack + Height Down ---- */
        if(goBack && heightDn)
        {
            if(!comboLatch_Slide)
            {
                comboLatch_Slide  = 1;
                comboLatch_Tilt   = 0;
                comboLatch_Height = 0;

                ACTION_SendCommand(0x00);
                LCD_StopCircularAnim();
                LCD_ShowSensorPage(GOBACK_HEIGHT);
            }
            return;
        }
        else comboLatch_Slide = 0;

        /* ---- GoBack + Flex Up ---- */
        if(goBack && flexUp)
        {
            if(!comboLatch_Tilt)
            {
                comboLatch_Tilt   = 1;
                comboLatch_Slide  = 0;
                comboLatch_Height = 0;

                ACTION_SendCommand(0x00);
                LCD_StopCircularAnim();
                LCD_ShowSensorPage(GOBACK_FLEX);
            }
            return;
        }
        else comboLatch_Tilt = 0;

        /* ---- GoBack + Slide ---- */
        if(goBack && slide)
        {
            ACTION_SendCommand(0x00);
            LCD_StopCircularAnim();
            LCD_ShowSensorPage(GOBACK_HEIGHT);
            return;
        }
    }

    /* ================= SINGLE KEY PROCESS ================= */

    for(int c = 0; c < 7; c++)
    {
        for(int r = 0; r < 5; r++)
        {
            uint8_t pressed = (stableCount[c][r] >= DEBOUNCE_TRIGGER);

            if(pressed && !key_matrix[c][r])
            {
                key_matrix[c][r] = 1;

                /* ----- HARD KEYS ----- */

                if(c == 4 && r == 3) { LCD_SetLock(1); continue; }
                if(c == 4 && r == 0) { LCD_SetLock(0); continue; }

                if(c == 6 && r == 3)
                {
                    if(!LCD_IsLocked())
                        LCD_ToggleReverse();
                    continue;
                }

                if(c == 6 && r == 0)
                {
                    LCD_TogglePower();
                    continue;
                }

                if(LCD_IsLocked() || !LCD_IsPowerOn())
                    continue;

                /* ===== SINGLE GOBACK → HOME ===== */

                if(c == 1 && r == 3)
                {
                    LCD_ShowSensorPage(PAGE_HOME);   // 👈 your home page define
                    continue;
                }

                /* ----- PAGE BUTTONS ----- */

                if(c == 1 && r == 1)
                {
                    LCD_ShowSensorPage(SETTING);
                    continue;
                }

                if(c == 1 && r == 2)
                {
                    LCD_ShowSensorPage(DETAILS);
                    continue;
                }

                if(c == 5 && r == 3)
                {
                    LCD_ShowSensorPage(MOMORY);
                    continue;
                }

                /* ----- NORMAL MOVEMENT KEYS ----- */

                uint8_t cmd = keyCmdCode[c][r];

                if(cmd)
                {
                    ACTION_SendCommand(cmd);
                    LCD_HandleKey(cmd);

                    if(Sensor_IsActive())
                        Sensor_ProcessKeys(cmd);
                }
            }

            /* ----- RELEASE ----- */

            if(!pressed && key_matrix[c][r])
            {
                key_matrix[c][r] = 0;

                if(!LCD_IsLocked() && LCD_IsPowerOn())
                {
                    ACTION_SendCommand(0x00);
                    LCD_StopCircularAnim();
                }
            }
        }
    }
}
