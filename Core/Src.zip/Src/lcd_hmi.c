#include "lcd_hmi.h"
#include "main.h"
#include "sensor_manager.h"
#include <stdint.h>

#define PAGE_HOME        0x04
#define PAGE_FLEX        0x05
#define PAGE_HEIGHT      0x07
#define PAGE_TREND       0x08
#define PAGE_BACK        0x09
#define PAGE_SLIDE       0x0A
#define PAGE_TILT        0x0B
#define PAGE_LOCK        0x0C
#define PAGE_POWER_OFF   0x1E
#define IA_FLEX     0x40
#define IA_HEIGHT   0x42
#define IA_TREND    0x43
#define IA_BACK     0x44
#define IA_SLIDE    0x45
#define IA_TILT     0x46
#define HOME_RETURN_TIME 4000
#define CIRC_INC(val, max)   do { (val)++; if((val) > (max)) (val) = 0; } while(0)
#define CIRC_DEC(val, max)   do { if((val) == 0) (val) = (max); else (val)--; } while(0)
static UART_HandleTypeDef *lcd_uart = NULL;
static uint8_t currentPage = 0xFF;
static uint32_t homeTimer = 0;
static uint8_t homeActive = 0;
static uint8_t heightState = 0;
static uint8_t trendState  = 0;
static uint8_t backState   = 0;
static uint8_t tiltState   = 2;
static uint8_t slideState  = 0;
static uint8_t flexState   = 0;
static uint8_t reverseMode = 0;
static uint8_t lcdPowerOn  = 1;
static uint8_t lcdLocked   = 0;
static uint8_t  animActive = 0;
static uint8_t  animCmd    = 0;
static uint32_t animTick   = 0;
static int8_t   animDir    = 1;

void LCD_HMI_Init(UART_HandleTypeDef *huart)
{
    lcd_uart = huart;
    currentPage = 0xFF;
    homeActive = 0;
    homeTimer = 0;
}

static void LCD_SendPage(uint8_t page)
{
    if(lcd_uart == NULL) return;
    uint8_t packet[10] = {0x5A,0xA5, 0x07, 0x82, 0x00,0x84, 0x5A,0x01, 0x00,page};
    HAL_UART_Transmit(lcd_uart, packet, 10, 100);
}

static void LCD_SendIcon(uint8_t iconAddr, uint8_t state)
{
    if(lcd_uart == NULL) return;
    uint8_t packet[8] ={0x5A,0xA5, 0x05, 0x82, 0x00,iconAddr, 0x00,state};
    HAL_UART_Transmit(lcd_uart, packet, 8, 100);
}

static void LCD_Show(uint8_t page, uint8_t iconAddr, uint8_t state)
{
    if(currentPage != page)
    {
        LCD_SendPage(page);
        currentPage = page;
        HAL_Delay(20);
    }
    LCD_SendIcon(iconAddr, state);
    homeTimer = HAL_GetTick();
    homeActive = 1;
}

static uint8_t MapReverse(uint8_t cmd)
{
    if(!reverseMode) return cmd;
    switch(cmd)
    {
        case 0x01: return 0x02;
        case 0x02: return 0x01;
        case 0x03: return 0x04;
        case 0x04: return 0x03;
        case 0x05: return 0x06;
        case 0x06: return 0x05;
        case 0x07: return 0x08;
        case 0x08: return 0x07;
        case 0x09: return 0x10;
        case 0x10: return 0x09;
        case 0x11: return 0x12;
        case 0x12: return 0x11;
        default:   return cmd;
    }
}

void LCD_SetLock(uint8_t state)
{
    lcdLocked = state;
    animActive = 0;
    homeActive = 0;
    if(state)
    {
        LCD_SendPage(PAGE_LOCK);
        currentPage = PAGE_LOCK;
    }
    else
    {
        LCD_SendPage(PAGE_HOME);
        currentPage = PAGE_HOME;
    }
}
uint8_t LCD_IsLocked(void)
{
    return lcdLocked;
}
uint8_t LCD_IsPowerOn(void)
{
    return lcdPowerOn;
}
void LCD_HandleKey(uint8_t cmd)
{
    if(!lcdPowerOn || lcdLocked)
        return;
    cmd = MapReverse(cmd);
    switch(cmd)
    {
        case 0x01: CIRC_INC(heightState,4);
                   LCD_Show(PAGE_HEIGHT, IA_HEIGHT, heightState); break;
        case 0x02: CIRC_DEC(heightState,4);
                   LCD_Show(PAGE_HEIGHT, IA_HEIGHT, heightState); break;
        case 0x03: CIRC_INC(trendState,4);
                   LCD_Show(PAGE_TREND, IA_TREND, trendState); break;
        case 0x04: CIRC_DEC(trendState,4);
                   LCD_Show(PAGE_TREND, IA_TREND, trendState); break;
        case 0x05: CIRC_INC(backState,4);
                   LCD_Show(PAGE_BACK, IA_BACK, backState); break;
        case 0x06: CIRC_DEC(backState,4);
                   LCD_Show(PAGE_BACK, IA_BACK, backState); break;
        case 0x07: CIRC_DEC(tiltState,4);
                   LCD_Show(PAGE_TILT, IA_TILT, tiltState); break;
        case 0x08: CIRC_INC(tiltState,4);
                   LCD_Show(PAGE_TILT, IA_TILT, tiltState); break;
        case 0x09: CIRC_INC(slideState,2);
                   LCD_Show(PAGE_SLIDE, IA_SLIDE, slideState); break;
        case 0x10: CIRC_DEC(slideState,2);
                   LCD_Show(PAGE_SLIDE, IA_SLIDE, slideState); break;
        case 0x11: flexState ^= 1;
                   LCD_Show(PAGE_FLEX, IA_FLEX, flexState); break;
        case 0x12: flexState ^= 1;
                   LCD_Show(PAGE_FLEX, IA_FLEX, flexState); break;

        default: break;
    }
}

void LCD_StartCircularAnim(uint8_t cmd)
{
    if(!lcdPowerOn || lcdLocked)
        return;
    animActive = 1;
    animCmd = cmd;
    animTick = HAL_GetTick();
    animDir = 1;
}

void LCD_StopCircularAnim(void)
{
    animActive = 0;
}

static void LCD_HandleCircularAnim(void)
{
    if(!animActive) return;
    if(HAL_GetTick() - animTick < 250) return;

    animTick = HAL_GetTick();

    uint8_t cmd = MapReverse(animCmd);
    LCD_HandleKey(cmd);
}
void LCD_ShowStartupSequence(void)
{
    if(lcd_uart == NULL)
        return;
    LCD_SendPage(0x01);
    HAL_Delay(400);
    LCD_SendPage(0x02);
    HAL_Delay(400);
    LCD_SendPage(0x03);
    HAL_Delay(400);
    LCD_SendPage(0x04);
    HAL_Delay(400);
    LCD_SendPage(PAGE_HOME);
    currentPage = PAGE_HOME;
}
void LCD_TogglePower(void)
{
    lcdPowerOn ^= 1;
    animActive = 0;
    homeActive = 0;
    if(lcdPowerOn)
    {
        LCD_ShowStartupSequence();
    }
    else
    {
        LCD_SendPage(PAGE_POWER_OFF);
        currentPage = PAGE_POWER_OFF;
    }
}

void LCD_ToggleReverse(void)
{
    reverseMode ^= 1;
}

static void LCD_GoHome(void)
{
    LCD_SendPage(PAGE_HOME);
    currentPage = PAGE_HOME;
    homeActive = 0;
}

void LCD_Task(void)
{
    LCD_HandleCircularAnim();
    if(homeActive && !Sensor_IsActive() && !lcdLocked && lcdPowerOn)
    {
        if(HAL_GetTick() - homeTimer >= HOME_RETURN_TIME)
        {
            LCD_GoHome();
        }
    }
}
void LCD_ShowSensorPage(uint8_t page)
{
    if(!lcdPowerOn || lcdLocked)
        return;
    animActive = 0;
    homeActive = 0;
    if(currentPage != page)
    {
        LCD_SendPage(page);
        currentPage = page;
        HAL_Delay(20);
    }
}

void LCD_UpdateSensorIcon(uint8_t iconAddr, uint8_t state)
{
    if(!lcdPowerOn || lcd_uart == NULL)
        return;
    LCD_SendIcon(iconAddr, state);
}
