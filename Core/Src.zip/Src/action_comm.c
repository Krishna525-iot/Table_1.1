#include "action_comm.h"
#include "sensor_manager.h"
#include <string.h>

static UART_HandleTypeDef *uart_bt;
static UART_HandleTypeDef *uart_act;
#define PACKET_SIZE         16
#define SENSOR_PACKET_SIZE  25
#define HEADER_BYTE1  0x43
#define HEADER_BYTE2  0x47
static const uint8_t basePacket[PACKET_SIZE] ={0x43,0x47,0xFE,0x00,0x00,0x00,0x00,0x01,0x00,0x95,0xA5,0xB5,0xC5,0xD5,0x00,0x4E};
static uint8_t txPacket[PACKET_SIZE];
static uint8_t rxByte;
static uint8_t packetBuffer[SENSOR_PACKET_SIZE];
static uint8_t packetIndex = 0;
static uint8_t headerState = 0;

void ACTION_COMM_Init(UART_HandleTypeDef *huart_bt,
                      UART_HandleTypeDef *huart_act)
{
    uart_bt  = huart_bt;
    uart_act = huart_act;
    packetIndex = 0;
    headerState = 0;
    HAL_UART_Receive_IT(uart_bt, &rxByte, 1);
}

void ACTION_SendCommand(uint8_t cmd)
{
    memcpy(txPacket, basePacket, PACKET_SIZE);
    txPacket[3] = cmd;
    HAL_UART_Transmit(uart_bt, txPacket, PACKET_SIZE, HAL_MAX_DELAY);
    if (uart_act != NULL)
        HAL_UART_Transmit(uart_act, txPacket, PACKET_SIZE, HAL_MAX_DELAY);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == uart_bt)
    {
        switch(headerState)
        {
            case 0:
                if(rxByte == HEADER_BYTE1)
                {
                    packetBuffer[0] = rxByte;
                    packetIndex = 1;
                    headerState = 1;
                }
                break;
            case 1:
                if(rxByte == HEADER_BYTE2)
                {
                    packetBuffer[1] = rxByte;
                    packetIndex = 2;
                    headerState = 2;
                }
                else
                {
                    headerState = 0;
                    packetIndex = 0;
                }
                break;
            case 2:
                packetBuffer[packetIndex++] = rxByte;
                if(packetIndex >= SENSOR_PACKET_SIZE)
                {
                    Sensor_ParsePacket(&packetBuffer[2]);
                    packetIndex = 0;
                    headerState = 0;
                }
                break;
        }
        HAL_UART_Receive_IT(uart_bt, &rxByte, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart == uart_bt)
    {
        packetIndex = 0;
        headerState = 0;
        HAL_UART_Receive_IT(uart_bt, &rxByte, 1);
    }
}
