#include "sensor_manager.h"
#include "lcd_hmi.h"
static SensorState_t sensorState;
static uint8_t selected_sensor = 0;
static uint8_t edit_mode = 0;
static uint8_t sensorPageActive = 0;
#define PAGE_SENSOR_1        0x0D
#define IA_SENSOR_TILT_L     0x50
#define IA_SENSOR_TILT_R     0x51
#define IA_SENSOR_BACK_UP    0x52
#define IA_SENSOR_BACK_DN    0x53
#define IA_SENSOR_TREND      0x54
#define IA_SENSOR_REV        0x55
static void increaseValue(void);
static void decreaseValue(void);
static uint8_t testModeActive = 0;
static uint8_t testSensorType = 0;
static uint8_t testValue = 0;

void Sensor_Init(void)
{
    selected_sensor = 0;
    edit_mode = 0;
    sensorPageActive = 0;
}

void Sensor_SetActive(uint8_t state)
{
    sensorPageActive = state;
    if(sensorPageActive)
    {
        LCD_ShowSensorPage(PAGE_SENSOR_1);
    }
}

uint8_t Sensor_IsActive(void)
{
    return sensorPageActive;
}
void Sensor_ParsePacket(uint8_t *data)
{
    sensorState.tilt_left      = data[0];
    sensorState.tilt_right     = data[1];
    sensorState.back_up        = data[3];
    sensorState.back_down      = data[4];
    sensorState.trend          = data[5];
    sensorState.reverse_trend  = data[6];
    if(sensorPageActive)
        Sensor_UpdateDisplay();
}
void Sensor_UpdateDisplay(void)
{
    if(!sensorPageActive)
        return;
    LCD_UpdateSensorIcon(IA_SENSOR_TILT_L,  sensorState.tilt_left);
    LCD_UpdateSensorIcon(IA_SENSOR_TILT_R,  sensorState.tilt_right);
    LCD_UpdateSensorIcon(IA_SENSOR_BACK_UP, sensorState.back_up);
    LCD_UpdateSensorIcon(IA_SENSOR_BACK_DN, sensorState.back_down);
    LCD_UpdateSensorIcon(IA_SENSOR_TREND,   sensorState.trend);
    LCD_UpdateSensorIcon(IA_SENSOR_REV,     sensorState.reverse_trend);
}
void Sensor_ProcessKeys(uint8_t cmd)
{
    if(!sensorPageActive)
        return;
    edit_mode = 1;
    switch(cmd)
    {
        case 0x01:
            increaseValue();
            break;
        case 0x02:
            decreaseValue();
            break;
        case 0x03:
            if(selected_sensor < 5)
                selected_sensor++;
            break;
        case 0x04:
            if(selected_sensor > 0)
                selected_sensor--;
            break;
        default:
            break;
    }
}
void Sensor_LoadTestPage(uint8_t sensorType)
{
    testModeActive = 1;
    testSensorType = sensorType;
    switch(sensorType)
    {
        case SENSOR_TILT:
            testValue = sensorState.tilt_left;
            break;
        case SENSOR_SLIDE:
            testValue = sensorState.trend;
            break;
        case SENSOR_BACK:
            testValue = sensorState.back_up;
            break;
        default:
            testModeActive = 0;
            return;
    }
    Sensor_UpdateDisplay();
}
static void increaseValue(void)
{
    switch(selected_sensor)
    {
        case 0: sensorState.tilt_left++; break;
        case 1: sensorState.tilt_right++; break;
        case 2: sensorState.back_up++; break;
        case 3: sensorState.back_down++; break;
        case 4: sensorState.trend++; break;
        case 5: sensorState.reverse_trend++; break;
    }
}

static void decreaseValue(void)
{
    switch(selected_sensor)
    {
        case 0: if(sensorState.tilt_left>0) sensorState.tilt_left--; break;
        case 1: if(sensorState.tilt_right>0) sensorState.tilt_right--; break;
        case 2: if(sensorState.back_up>0) sensorState.back_up--; break;
        case 3: if(sensorState.back_down>0) sensorState.back_down--; break;
        case 4: if(sensorState.trend>0) sensorState.trend--; break;
        case 5: if(sensorState.reverse_trend>0) sensorState.reverse_trend--; break;
    }
}
