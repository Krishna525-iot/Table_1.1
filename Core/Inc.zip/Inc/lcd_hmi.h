#ifndef __LCD_HMI_H
#define __LCD_HMI_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

#define PAGE_HOME        0x04
#define PAGE_FLEX        0x05
#define PAGE_HEIGHT      0x07
#define PAGE_TREND       0x08
#define PAGE_BACK        0x09
#define PAGE_SLIDE       0x0A
#define PAGE_TILT        0x0B
#define PAGE_LOCK        0x0C
#define PAGE_POWER_OFF   0x1E
#define GOBACK_ACCEPT    0x0F
#define GOBACK_HEIGHT    0x0E
#define GOBACK_FLEX      0x0D
#define SETTING      	 0x14
#define DETAILS		     0x11
#define MOMORY		     0x10
#define REVERSE_BUTTON_CMD  0x28
void LCD_HMI_Init(UART_HandleTypeDef *huart);
void LCD_HandleKey(uint8_t cmd);
void LCD_Task(void);
void LCD_TogglePower(void);
uint8_t LCD_IsPowerOn(void);
void LCD_SetLock(uint8_t state);
uint8_t LCD_IsLocked(void);
void LCD_ToggleReverse(void);
void LCD_ShowStartupSequence(void);
void LCD_StartCircularAnim(uint8_t cmd);
void LCD_StopCircularAnim(void);
void LCD_ShowSensorPage(uint8_t page);
void LCD_UpdateSensorIcon(uint8_t iconAddr, uint8_t state);
void lcd_set_page(uint8_t page);
void lcd_set_icon(uint8_t icon, uint8_t value);
void lcd_set_cursor_position(uint8_t pos);

#endif
