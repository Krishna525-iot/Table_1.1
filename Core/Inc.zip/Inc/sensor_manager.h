#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include <stdint.h>

#define SENSOR_TILT    0
#define SENSOR_SLIDE   1
#define SENSOR_BACK    2
typedef struct
{
    uint8_t tilt_left;
    uint8_t tilt_right;
    uint8_t back_up;
    uint8_t back_down;
    uint8_t trend;
    uint8_t reverse_trend;

} SensorState_t;
void Sensor_Init(void);
void Sensor_SetActive(uint8_t state);
uint8_t Sensor_IsActive(void);
void Sensor_ParsePacket(uint8_t *data);
void Sensor_UpdateDisplay(void);
void Sensor_ProcessKeys(uint8_t cmd);
void Sensor_LoadTestPage(uint8_t sensorType);

#endif
