#ifndef __ACTION_COMM_H
#define __ACTION_COMM_H

#include "stm32f1xx_hal.h"

void ACTION_COMM_Init(UART_HandleTypeDef *huart1,
                      UART_HandleTypeDef *huart3);
void ACTION_COMM_Task(void);

void ACTION_SendCommand(uint8_t cmd);

#endif
